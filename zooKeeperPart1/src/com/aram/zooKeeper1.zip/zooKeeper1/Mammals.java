package com.aram.zooKeeper1;

public class Mammals {
private int energyLevel;
	
	public Mammals() {
		energyLevel = 300;
	}
	
	//getters
	public int getEnergyLevel() {
		return energyLevel;
	}

	//setters
	public void setEnergyLevel(int energyLevel) {
		this.energyLevel = energyLevel;
	}


	public void displayEnergyLevel() {
		System.out.println(energyLevel);
	}
}

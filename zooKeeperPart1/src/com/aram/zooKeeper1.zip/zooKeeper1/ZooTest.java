package com.aram.zooKeeper1;

public class ZooTest {
	
	public static void main(String[] args) {
		Gorilla gorilla = new Gorilla();
		gorilla.throwSomething();//Look out...
		gorilla.throwSomething();//Look out...
		gorilla.throwSomething();//Look out...
		
		gorilla.eatBananas();//yep
		gorilla.eatBananas();//yep
		
		gorilla.climb();//climbing
		gorilla.displayEnergyLevel();//95
		
	}
	

}
